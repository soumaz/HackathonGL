﻿using System;
using System.Net;

namespace WcfService1_Location
{
    public class Bus
    {
        public String name { set; get; }
        public int number { set; get; }

        /*public String getName()
        {
            return this.name;
        }

        public void setName(String s)
        {
            this.name = s;
        }

        public int getNumber()
        {
            return this.number;
        }

        public void setNumber(int s)
        {
            this.number = s;
        }*/
    }
}
